package com.kircherelectronics.accelerationexplorer.filter;

/*
 * Acceleration Explorer
 * Copyright (C) 2013-2015, Kaleb Kircher - Kircher Engineering, LLC
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/**
 * An interface for linear acceleration filters.
 * 
 * @author Kaleb
 *
 */
public interface ImuLinearAccelerationInterface
{
	/**
	 * Get the linear acceleration of the device. This method can be called
	 * *only* after setAcceleration(), setMagnetic() and getGyroscope() have
	 * been called.
	 * 
	 * @return float[] an array containing the linear acceleration of the device
	 *         where [0] = x, [1] = y and [2] = z with respect to the Android
	 *         coordinate system.
	 */
	public float[] getLinearAcceleration();

	/**
	 * The acceleration of the device. Presumably from Sensor.TYPE_ACCELERATION.
	 * 
	 * @param acceleration
	 *            The acceleration of the device.
	 */
	public void setAcceleration(float[] acceleration);

	/**
	 * Set the gyroscope rotation. Presumably from Sensor.TYPE_GYROSCOPE
	 * 
	 * @param gyroscope
	 *            the rotation of the device.
	 * @param timeStamp
	 *            the time the measurement was taken.
	 */
	public void setGyroscope(float[] gyroscope, long timeStamp);

	/**
	 * The complementary filter coefficient, a floating point value between 0-1,
	 * exclusive of 0, inclusive of 1.
	 * 
	 * @param filterCoefficient
	 */
	public void setFilterCoefficient(float filterCoefficient);

	/**
	 * Set the magnetic field... presumably from Sensorr.TYPE_MAGNETIC_FIELD.
	 * 
	 * @param magnetic
	 *            the magnetic field
	 */
	public void setMagnetic(float[] magnetic);
}
